 font - Beautify Script
https://www.dafont.com/beautify-script.font?l[]=10&l[]=1&text=FAIRY